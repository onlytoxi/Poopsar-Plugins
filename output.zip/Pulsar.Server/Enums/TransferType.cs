﻿namespace Pulsar.Server.Enums
{
    public enum TransferType
    {
        Upload,
        Download
    }
}
