﻿namespace Pulsar.Common.Enums
{
    public enum UserStatus
    {
        Active,
        Idle
    }
}
