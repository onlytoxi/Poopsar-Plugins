﻿namespace Pulsar.Common.Enums
{
    public enum AccountType
    {
        Admin,
        User,
        Guest,
        Unknown
    }
}
