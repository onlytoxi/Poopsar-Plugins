namespace Pulsar.Common.Enums
{
    public enum KematianStatus
    {
        Idle,
        Collecting,
        Completed,
        Failed
    }
} 