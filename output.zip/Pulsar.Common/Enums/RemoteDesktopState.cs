﻿namespace Pulsar.Common.Enums
{
    public enum RemoteDesktopStatus
    {
        Start,
        Stop,
        Continue,
    }

    public enum RemoteWebcamStatus
    {
        Start,
        Stop,
        Continue,
    }
}
