﻿namespace Pulsar.Common.Enums
{
    public enum FileType
    {
        File,
        Directory,
        Back
    }
}
