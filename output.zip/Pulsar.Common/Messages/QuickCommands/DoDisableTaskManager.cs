﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.QuickCommands
{
    [ProtoContract]
    public class DoDisableTaskManager : IMessage
    {

    }
}
