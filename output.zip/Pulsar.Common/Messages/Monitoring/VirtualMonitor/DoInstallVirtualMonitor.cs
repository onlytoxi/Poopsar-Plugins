﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Monitoring.VirtualMonitor
{
    [ProtoContract]
    public class DoInstallVirtualMonitor : IMessage
    {
    }
}