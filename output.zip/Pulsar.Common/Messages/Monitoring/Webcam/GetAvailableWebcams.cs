﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Webcam
{
    [ProtoContract]
    public class GetAvailableWebcams : IMessage
    {
    }
}
