﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Monitoring.Query
{
    [ProtoContract]
    public class GetBrowsers : IMessage
    {

    }
}
