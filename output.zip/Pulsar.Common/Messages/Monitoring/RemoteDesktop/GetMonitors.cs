﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Monitoring.RemoteDesktop
{
    [ProtoContract]
    public class GetMonitors : IMessage
    {
    }
}
