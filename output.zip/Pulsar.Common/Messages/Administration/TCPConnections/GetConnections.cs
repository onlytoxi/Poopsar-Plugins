﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Administration.TCPConnections
{
    [ProtoContract]
    public class GetConnections : IMessage
    {
    }
}
