﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Administration.StartupManager
{
    [ProtoContract]
    public class GetStartupItems : IMessage
    {
    }
}
