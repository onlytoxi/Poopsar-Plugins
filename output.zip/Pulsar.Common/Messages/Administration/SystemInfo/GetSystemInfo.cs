﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Administration.SystemInfo
{
    [ProtoContract]
    public class GetSystemInfo : IMessage
    {
    }
}
