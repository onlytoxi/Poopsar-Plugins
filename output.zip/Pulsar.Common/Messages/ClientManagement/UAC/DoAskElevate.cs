﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.ClientManagement.UAC
{
    [ProtoContract]
    public class DoAskElevate : IMessage
    {
    }
}
