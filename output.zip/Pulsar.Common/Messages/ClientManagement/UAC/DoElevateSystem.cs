﻿using ProtoBuf;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.ClientManagement
{
    [ProtoContract]
    public class DoElevateSystem : IMessage
    {
    }
}
