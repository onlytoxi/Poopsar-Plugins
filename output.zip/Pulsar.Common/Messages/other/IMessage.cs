﻿namespace Pulsar.Common.Messages.Other
{
    public interface IMessage
    {
    }
}
